import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';

import 'core/colors.dart';
import 'screens/splash.dart';

// Models
import 'models/product.dart';
import 'models/sale.dart';
import 'models/purchase.dart';
import 'models/inventory_loss.dart';
import 'models/sale_item.dart';

// Services
import 'services/storage_service.dart';

// Repositories
import 'repositories/auth_repository.dart';
import 'repositories/profile_repository.dart';
import 'repositories/inventory_repository.dart';
import 'repositories/notification_repository.dart';
import 'repositories/product_repository.dart';
import 'repositories/loss_repository.dart';

// Providers
import 'providers/product_provider.dart';
import 'providers/sale_provider.dart';
import 'providers/alert_provider.dart';
import 'providers/navigation_provider.dart';
import 'providers/profile_provider.dart';
import 'providers/inventory_provider.dart';
import 'providers/notification_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/purchase_provider.dart';
import 'providers/purchase_form_provider.dart';
import 'providers/product_form_provider.dart';
import 'providers/loss_provider.dart';
import 'providers/sale_form_provider.dart';
import 'providers/scanner_provider.dart';
import 'providers/log_loss_form_provider.dart';
import 'providers/loss_filter_provider.dart';
import 'providers/inventory_filter_provider.dart';
import 'providers/product_unit_provider.dart';
import 'providers/brand_search_provider.dart';
import 'providers/category_search_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  await Hive.openBox('appBox');
  await Hive.openBox('settings');

  if (!Hive.isAdapterRegistered(0)) Hive.registerAdapter(ProductAdapter());
  if (!Hive.isAdapterRegistered(1)) Hive.registerAdapter(SaleAdapter());
  if (!Hive.isAdapterRegistered(3)) Hive.registerAdapter(SaleItemAdapter());
  if (!Hive.isAdapterRegistered(4)) Hive.registerAdapter(PurchaseAdapter());
  if (!Hive.isAdapterRegistered(5)) Hive.registerAdapter(InventoryLossAdapter());
  

  await Hive.openBox<Product>('products');
  await Hive.openBox<Sale>('sales');
  await Hive.openBox<Purchase>('purchases');
  await Hive.openBox<InventoryLoss>('losses');

  runApp(
    MultiProvider(
      providers: [

        // SERVICES 
        Provider<StorageService>(
          create: (_) => StorageService(),
        ),

        // REPOSITORIES
        ProxyProvider<StorageService, AuthRepository>(
          update: (_, storage, __) => AuthRepository(storage),
        ),
        ProxyProvider<StorageService, ProfileRepository>(
          update: (_, storage, __) => ProfileRepository(storage),
        ),
        ProxyProvider<StorageService, InventoryRepository>(
          update: (_, storage, __) => InventoryRepository(storage),
        ),
        ProxyProvider<StorageService, NotificationRepository>(
          update: (_, storage, __) => NotificationRepository(storage),
        ),
        Provider<ProductRepository>(
          create: (_) => ProductRepository(),
        ),

        // PROVIDERS 
        ChangeNotifierProxyProvider2<AuthRepository, ProfileRepository, ProfileProvider>(
          create: (ctx) => ProfileProvider(
            ctx.read<AuthRepository>(),
            ctx.read<ProfileRepository>(),
          ),
          update: (_, authRepo, profileRepo, prev) =>
              prev ?? ProfileProvider(authRepo, profileRepo),
        ),

        ChangeNotifierProvider(create: (_) => NavigationProvider()),

        ChangeNotifierProxyProvider<ProductRepository, ProductProvider>(
          create: (ctx) => ProductProvider(ctx.read<ProductRepository>()),
          update: (_, repo, prev) => prev ?? ProductProvider(repo),
        ),

        ChangeNotifierProxyProvider<InventoryRepository, InventoryProvider>(
          create: (ctx) => InventoryProvider(ctx.read<InventoryRepository>()),
          update: (_, repo, prev) => prev ?? InventoryProvider(repo),
        ),

        ChangeNotifierProvider(create: (_) => SaleProvider()),
        ChangeNotifierProvider(create: (_) => AlertProvider()),
        ChangeNotifierProvider(create: (_) => PurchaseProvider()),
        ChangeNotifierProvider(create: (_) => PurchaseFormProvider()),
        ChangeNotifierProvider(create: (_) => ProductFormProvider()),
        ChangeNotifierProvider(create: (_) => LossProvider(LossRepository())),

        // NOTIFICATION PROVIDER
        ChangeNotifierProxyProvider3<NotificationRepository, ProductProvider, SaleProvider, NotificationProvider>(
          create: (ctx) => NotificationProvider(
            ctx.read<NotificationRepository>(),
          ),
          update: (_, repo, pp, sp, prev) =>
              (prev ?? NotificationProvider(repo))..update(pp, sp),
        ),

        ChangeNotifierProvider(create: (_) => SettingsProvider()),

        
        ChangeNotifierProvider(create: (_) => SaleFormProvider()),
        ChangeNotifierProvider(create: (_) => ScannerProvider()),
        ChangeNotifierProvider(create: (_) => LogLossFormProvider()),
        ChangeNotifierProvider(create: (_) => LossFilterProvider()),
        ChangeNotifierProvider(create: (_) => InventoryFilterProvider()),
        ChangeNotifierProvider(create: (_) => ProductUnitProvider()),
        ChangeNotifierProvider(create: (_) => BrandSearchProvider()),
        ChangeNotifierProvider(create: (_) => CategorySearchProvider()),
        

      ],
      child: const StockSenseApp(),
    ),
  );
}

class StockSenseApp extends StatelessWidget {
  const StockSenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'StockSense',
      theme: ThemeData(
        scaffoldBackgroundColor: AppColors.white,
        primaryColor: AppColors.primary,
      ),
      home: Splash(),
    );
  }
}