import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// Responsive helper — supports phone, tablet, and web.
/// Call [Responsive.init] once per build, then use helpers freely.
///
/// Usage:
///   Responsive.init(context);
///   Text('Hi', style: TextStyle(fontSize: Responsive.sp(16)))
///   Padding(padding: EdgeInsets.all(Responsive.pagePadding))

class Responsive {
  Responsive._();

  static late double _width;
  static late double _height;
  static late double _devicePixelRatio;

  /// Design base width (360 = typical phone).
  static const double _base = 360.0;

  static void init(BuildContext context) {
    final mq = MediaQuery.of(context);
    _width             = mq.size.width;
    _height            = mq.size.height;
    _devicePixelRatio  = mq.devicePixelRatio;
  }

  // ── Breakpoints ─────────────────────────────────────────────────────────────
  // Web: treat browser window width as the breakpoint signal.

  static bool get isPhone       => _width < 600;
  static bool get isTablet      => _width >= 600 && _width < 1024;
  static bool get isDesktop     => _width >= 1024;
  static bool get isWeb         => kIsWeb;
  static bool get isNarrow      => _width < 400;    // very small phones

  // ── Adaptive values ──────────────────────────────────────────────────────────

  /// Return [phone], [tablet], or [desktop] based on current width.
  static T when<T>({required T phone, T? tablet, T? desktop}) {
    if (isDesktop && desktop != null) return desktop;
    if (isTablet  && tablet  != null) return tablet;
    return phone;
  }

  // ── Spacing / sizing helpers ─────────────────────────────────────────────────

  /// Scale a size proportionally to screen width.
  /// On web/desktop capped so text doesn't grow absurdly large.
  static double sp(double size) {
    final scale  = (_width / _base).clamp(0.75, isDesktop ? 1.15 : 1.3);
    return size * scale;
  }

  /// Percentage of screen width.
  static double wp(double pct) => _width  * pct / 100;

  /// Percentage of screen height.
  static double hp(double pct) => _height * pct / 100;

  // ── Layout constants ─────────────────────────────────────────────────────────

  /// Horizontal page padding.
  static double get pagePadding  => when(phone: 16.0, tablet: 24.0, desktop: 32.0);

  /// Max content width (web) — content never stretches beyond this.
  static double get maxContentWidth => isDesktop ? 1200.0 : double.infinity;

  /// Sidebar width when present on web/tablet.
  static double get sidebarWidth => when(phone: 0.0, tablet: 72.0, desktop: 220.0);

  /// Show sidebar (not bottom nav) on tablet+.
  static bool get showSidebar => !isPhone;

  /// Card grid columns.
  static int get gridColumns => when(phone: 1, tablet: 2, desktop: 3);

  /// Vertical rhythm gap.
  static double get gap => when(phone: 12.0, tablet: 16.0, desktop: 20.0);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ADAPTIVE SCAFFOLD
//  Wraps your existing screens:
//  - Phone:   keeps the BottomNavigationBar from home_screen.dart
//  - Web/Tablet: shows a side rail instead.
// ─────────────────────────────────────────────────────────────────────────────

class AdaptiveScaffold extends StatelessWidget {
  final Widget body;
  final Widget? bottomNav;
  final Widget? sideRail;

  const AdaptiveScaffold({
    super.key,
    required this.body,
    this.bottomNav,
    this.sideRail,
  });

  @override
  Widget build(BuildContext context) {
    Responsive.init(context);
    if (Responsive.showSidebar && sideRail != null) {
      return Scaffold(
        body: Row(
          children: [
            sideRail!,
            const VerticalDivider(width: 1),
            Expanded(child: body),
          ],
        ),
      );
    }
    return Scaffold(
      body: body,
      bottomNavigationBar: bottomNav,
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  RESPONSIVE PADDING WRAPPER
//  Use this to constrain and center content on wide screens.
// ─────────────────────────────────────────────────────────────────────────────

class PagePadding extends StatelessWidget {
  final Widget child;
  const PagePadding({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    Responsive.init(context);
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: Responsive.maxContentWidth),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: Responsive.pagePadding),
          child: child,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  RESPONSIVE GRID
//  Replaces the hard-coded Row(...) patterns in home_screen.dart.
// ─────────────────────────────────────────────────────────────────────────────

class ResponsiveGrid extends StatelessWidget {
  final List<Widget> children;
  final int? columns;
  final double spacing;

  const ResponsiveGrid({
    super.key,
    required this.children,
    this.columns,
    this.spacing = 12,
  });

  @override
  Widget build(BuildContext context) {
    Responsive.init(context);
    final cols = columns ?? Responsive.gridColumns;
    return Wrap(
      spacing: spacing,
      runSpacing: spacing,
      children: children.map((child) => SizedBox(
        width: (MediaQuery.sizeOf(context).width
              - Responsive.pagePadding * 2
              - spacing * (cols - 1))
            / cols,
        child: child,
      )).toList(),
    );
  }
}